Zachary Cloutier - 38485403
Harris Barber - 61963675
Shaolong Lin - 36039856
Kevin Chao - 90751448


How to run:
-Run the server by running the visual studio project
-Run the html file labeled 38485403client and connect to the server
-Left and Right Arrow keys to move